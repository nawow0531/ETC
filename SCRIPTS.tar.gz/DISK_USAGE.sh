#! /bin/bash

HOME_DIR='/test/SCRIPT'

#CHK_DISK=`df -hP 2>/dev/null | awk -F " " '{print $5}' | sort -nr | awk -F "%" '{print $1}' | head -1 > /home/cocktail/mydata/SCRIPT/DISK_CHK`

#function DISK_USAGE_CHECK
#{
#$HOME_DIR/Disk_Usage.sh > $HOME_DIR/DISK_CHK
#RESULT_DISK=`cat /test/SCRIPT/DISK_CHK`
#rm -rf $HOME_DIR/DISK_CHK
#}



Result_Value=`df -hP 2>/dev/null | awk -F " " '{print $5}' | sort -nr | awk -F "%" '{print $1}' | head -1`
echo "$Result_Value"

