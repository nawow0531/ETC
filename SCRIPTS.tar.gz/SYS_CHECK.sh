#! /bin/bash

. /test/SCRIPT/Result.inc
. /test/SCRIPT/syschk.inc

HOME_PATH='/mnt/'
Enddate=`date +%Y%m%d`
resultfiletime=`date +%H%M%S`

if [ ! -d ${HOME_PATH}${Enddate} ]
then
    mkdir ${HOME_PATH}${Enddate}
fi

rm -f ${HOME_PATH}${Enddate}/${HOSTNAME}_Check_result_*.dat

F01_DISK_USAGE_CHECK
F02_IP_CHECK
F03_CPU_USAGE_CHECK

clear;
MENU > ${HOME_PATH}${Enddate}/${HOSTNAME}_Check_result_${resultfiletime}.dat

cat ${HOME_PATH}${Enddate}/${HOSTNAME}_Check_result_${resultfiletime}.dat

echo "Row Data FILE"
echo "${HOME_PATH}${Enddate}/${HOSTNAME}_Check_result_${resultfiletime}.dat"

